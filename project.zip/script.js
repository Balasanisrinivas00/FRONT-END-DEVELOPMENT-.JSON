async function fetchPatientData() {
  const API_URL = 'https://api.coalitiontechnologies.com/patients';

  try {
    const response = await fetch(API_URL);
    const data = await response.json();
    const patient = data.find(p => p.name === 'Jessica Taylor');

    if (patient) {
      document.getElementById('age').textContent = patient.age;
      document.getElementById('bloodType').textContent = patient.bloodType;

      const bloodPressureData = {
        labels: patient.bloodPressure.map(bp => bp.year),
        datasets: [
          {
            label: 'Blood Pressure',
            data: patient.bloodPressure.map(bp => bp.value),
            borderColor: 'rgba(75, 192, 192, 1)',
            backgroundColor: 'rgba(75, 192, 192, 0.2)',
            borderWidth: 2,
          },
        ],
      };

      const ctx = document.getElementById('bloodPressureChart').getContext('2d');
      new Chart(ctx, {
        type: 'line',
        data: bloodPressureData,
      });
    }
  } catch (error) {
    console.error('Error fetching patient data:', error);
  }
}

fetchPatientData();